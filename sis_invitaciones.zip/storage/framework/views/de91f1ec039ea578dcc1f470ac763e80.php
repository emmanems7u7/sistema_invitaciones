<form id="form_invitados" method="POST" action="<?php echo e(route('invitados.store', $invitacion)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo $__env->make('invitados._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form><?php /**PATH C:\xamppf\htdocs\sis_invitaciones\resources\views/invitados/create.blade.php ENDPATH**/ ?>